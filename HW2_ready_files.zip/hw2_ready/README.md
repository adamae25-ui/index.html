# HW2 (HTML/CSS)

## Pages
- `mtala.html` – Part A (manual, plain CSS)
- `copilot-plain.html` – Part B (plain CSS, Copilot-style)
- `copilot-flex.html` – Part B (Flexbox, same HTML classes as plain)
- `copilot-bootstrap.html` – Part B (Bootstrap)

## Index
Open `index.html` to navigate to all pages.

## GitHub Pages
After pushing to GitHub:
1. Settings → Pages
2. Source: Deploy from a branch
3. Branch: `main` / root
4. Your site will be published (paste the link here)

